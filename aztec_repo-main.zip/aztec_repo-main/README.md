# aztec_repo

Aztec is a privacy-first zkEVM rollup that brings programmable privacy and scalability to Ethereum using zero-knowledge proofs, enabling private transactions and hybrid public/private workflows
